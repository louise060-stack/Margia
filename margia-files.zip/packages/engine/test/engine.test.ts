/**
 * Engine acceptance tests — locked to PRD Section 6A.7's own criteria.
 * Run: npm run test:engine
 */
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readdirSync, readFileSync, existsSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

import {
  generatePlan,
  channelsCollide,
  computeGaps,
  buildHealthNudge,
  applyChecklistChange,
  rescoreAllUsers,
  DEFAULT_CHECKLIST,
  overlaps,
} from '../src/index.ts';
import type { PlanInput, FlexibleEvent } from '../src/index.ts';
import { sampleWeek, sampleWeekWithClearedNudge } from '../seed/sampleWeek.ts';

const __dirname = dirname(fileURLToPath(import.meta.url));

// ---------------------------------------------------------------------------
// 6A.7 — Inverted-default test
// "In a generated plan for an overfull week, every protected slot placed in
//  Pass 1 survives Pass 2. No flexible event ever displaces a protected
//  placement without an explicit user veto."
// ---------------------------------------------------------------------------

test('inverted default: every placed protected slot survives an overfull week', () => {
  // Cram the week with foreground obligations, then generate.
  const plan = generatePlan(sampleWeek);
  const placedProtected = plan.protected.filter((s) => s.placement);
  assert.ok(placedProtected.length >= 2, 'expected protected slots to be placed');

  for (const slot of placedProtected) {
    for (const ev of plan.flexible) {
      if (!ev.placement) continue;
      // choreographed/background co-runs are not claims on her time
      if (ev.is_background_process || ev.co_running_with.length > 0) continue;
      assert.ok(
        !overlaps(slot.placement!, ev.placement),
        `flexible "${ev.label}" displaced protected "${slot.label}" — inverted default violated`,
      );
    }
  }
});

// ---------------------------------------------------------------------------
// 6A.7 — Choreography test
// background attaches under a compatible foreground anchor, frees a block,
// a protected slot gets margin, and ONE human-readable reason is surfaced.
// The stacking rule is never violated.
// ---------------------------------------------------------------------------

test('choreography: laundry runs under a foreground, frees margin, surfaces one reason', () => {
  const plan = generatePlan(sampleWeek);

  const laundry = plan.flexible.find((e) => e.id === 'laundry')!;
  assert.ok(laundry.co_running_with.length > 0, 'laundry should be choreographed under an anchor');
  assert.ok(plan.marginMinutes > 0, 'choreography should manufacture margin');

  assert.ok(plan.surfacedMove, 'exactly one choreography move should be surfaced');
  assert.match(plan.surfacedMove!.reason, /laundry/i, 'the reason should name the real task');
  assert.ok(plan.surfacedMove!.reason.length > 20, 'the reason should be a real sentence, not a template id');

  const benefiting = plan.protected.find((s) => s.id === plan.surfacedMove!.filledProtectedId);
  assert.ok(benefiting?.hasMargin, 'the benefiting protected slot should be marked as sitting in margin');
});

test('stacking rule: no two HIGH-attention foreground events ever co-occupy time', () => {
  const plan = generatePlan(sampleWeek);
  const foregrounds = plan.flexible.filter(
    (e) => e.placement && e.attention_cost === 'HIGH' && e.co_running_with.length === 0,
  );
  for (let i = 0; i < foregrounds.length; i++) {
    for (let j = i + 1; j < foregrounds.length; j++) {
      assert.ok(
        !overlaps(foregrounds[i].placement!, foregrounds[j].placement!),
        `two HIGH-attention tasks overlap: "${foregrounds[i].label}" & "${foregrounds[j].label}"`,
      );
    }
  }
});

test('stacking rule: no choreographed co-run has colliding human channels', () => {
  const plan = generatePlan(sampleWeek);
  const byId = new Map(plan.flexible.map((e) => [e.id, e] as const));
  for (const ev of plan.flexible) {
    for (const partnerId of ev.co_running_with) {
      const partner = byId.get(partnerId);
      if (!partner) continue;
      // a background running unattended occupies no human channel — exclude it
      const evChannels = ev.is_background_process ? [] : ev.resource_channels;
      const pChannels = partner.is_background_process ? [] : partner.resource_channels;
      assert.ok(
        !channelsCollide(evChannels, pChannels),
        `co-run channel collision: "${ev.label}" ⇄ "${partner.label}"`,
      );
      // never two HIGH attention co-running
      assert.ok(
        !(ev.attention_cost === 'HIGH' && partner.attention_cost === 'HIGH'),
        `two HIGH-attention tasks co-run: "${ev.label}" ⇄ "${partner.label}"`,
      );
    }
  }
});

// ---------------------------------------------------------------------------
// Health layer — cited, age-gated, and GATED behind clinical sign-off
// ---------------------------------------------------------------------------

test('health: mammogram is age-gated (not applicable at 38, applicable at 42)', () => {
  const today = '2026-07-20';
  const at38 = computeGaps(38, [{ id: 'mammogram', last_done: null }], DEFAULT_CHECKLIST, today);
  assert.equal(at38.find((g) => g.id === 'mammogram')!.status, 'not_applicable');

  const at42 = computeGaps(42, [{ id: 'mammogram', last_done: null }], DEFAULT_CHECKLIST, today);
  assert.equal(at42.find((g) => g.id === 'mammogram')!.status, 'never_done');
});

test('health: cervical screening reads overdue with a citation', () => {
  const today = '2026-07-20';
  const gaps = computeGaps(38, [{ id: 'cervical', last_done: '2022-01-15' }], DEFAULT_CHECKLIST, today);
  const cervical = gaps.find((g) => g.id === 'cervical')!;
  assert.equal(cervical.status, 'overdue');
  assert.ok(cervical.months_overdue > 0);
  assert.match(cervical.guideline_source, /USPSTF/);
});

test('health: nudge is GATED — silent by default, only fires once cleared', () => {
  // DEFAULT checklist has nudge_enabled=false everywhere → no nudge, ever.
  const gated = generatePlan(sampleWeek);
  assert.equal(gated.healthNudge, null, 'no nudge should fire before clinical sign-off');

  // With the cervical nudge cleared (a stand-in for a signed-off screening) it fires.
  const cleared = generatePlan(sampleWeekWithClearedNudge);
  assert.ok(cleared.healthNudge, 'a cleared screening should surface its nudge');
  assert.match(cleared.healthNudge!.copy, /smear/i);
  assert.match(cleared.healthNudge!.guideline_source, /USPSTF/);
});

// ---------------------------------------------------------------------------
// The living document — versioned update mechanism (6A.3)
// "Editing one checklist row writes a correct history entry and, on re-score,
//  correctly reclassifies affected users' gap status — with no code deploy."
// ---------------------------------------------------------------------------

test('update mechanism: a guideline change writes history and re-scores users', () => {
  const today = '2026-07-20';
  // A user whose smear was 2.5 years ago is OK under a 36-month interval...
  const user = { userId: 'u1', age: 41, records: [{ id: 'cervical' as const, last_done: '2024-01-15' }] };
  const before = computeGaps(user.age, user.records, DEFAULT_CHECKLIST, today);
  assert.notEqual(before.find((g) => g.id === 'cervical')!.status, 'overdue');

  // ...a guideline tightens the interval to 24 months. Edit as DATA, with audit.
  const { checklist: next, history } = applyChecklistChange(DEFAULT_CHECKLIST, [], {
    screeningId: 'cervical',
    field: 'interval_months',
    new_value: 24,
    changed_at: '2026-07-20T09:00:00Z',
    reviewer: 'Dr. Example, MD',
    reason: 'Guideline interval revised',
    guideline_effective_date: '2026-06-01',
  });

  // history is append-only and records who/what/when/against-which-guideline
  assert.equal(history.length, 1);
  assert.equal(history[0].previous_value, 36);
  assert.equal(history[0].new_value, 24);
  assert.equal(history[0].reviewer, 'Dr. Example, MD');
  assert.equal(history[0].guideline_effective_date, '2026-06-01');

  // re-score flips the user into gap — with no code change
  const results = rescoreAllUsers([user], DEFAULT_CHECKLIST, next, today);
  assert.ok(results[0].newlyInGap.includes('cervical'), 'user should be newly in gap after the tightening');

  // and the original checklist is untouched (pure update)
  assert.equal(DEFAULT_CHECKLIST.find((d) => d.id === 'cervical')!.interval_months, 36);
});

// ---------------------------------------------------------------------------
// 6A.7 — Separability test
// "A grep of the front-end codebase finds no attention-cost rule, no stacking
//  rule, and no protected-vs-flexible decision."
// ---------------------------------------------------------------------------

test('separability: the web front end contains no engine logic', () => {
  const webDir = join(__dirname, '..', '..', '..', 'apps', 'web');
  if (!existsSync(webDir)) {
    // web app not built yet in this run — nothing to violate
    return;
  }
  const banned = [
    /placeProtected/,
    /arrangeFlexible/,
    /is_background_process\s*=/, // assigning/deriving the rule (reading a field is fine)
    /INTERLEAVE_SETUP_MAX/,
    /attention_cost\s*===\s*'HIGH'/, // making the stacking decision
  ];
  const offenders: string[] = [];
  for (const file of walk(webDir)) {
    if (!/\.(tsx?|jsx?)$/.test(file)) continue;
    if (file.includes('node_modules') || file.includes('.next')) continue;
    const src = readFileSync(file, 'utf8');
    for (const rule of banned) {
      if (rule.test(src)) offenders.push(`${file} :: ${rule}`);
    }
  }
  assert.equal(offenders.length, 0, `front end holds engine logic:\n${offenders.join('\n')}`);
});

function walk(dir: string): string[] {
  const out: string[] = [];
  for (const entry of readdirSync(dir, { withFileTypes: true })) {
    if (entry.name === 'node_modules' || entry.name === '.next') continue;
    const full = join(dir, entry.name);
    if (entry.isDirectory()) out.push(...walk(full));
    else out.push(full);
  }
  return out;
}

// keep the type import referenced
export type _Keep = PlanInput & FlexibleEvent;
