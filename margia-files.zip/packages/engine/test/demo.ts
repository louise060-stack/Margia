/* Run: npm run demo:engine  — prints the engine's reasoning over the sample week. */
import { generatePlan, fmt, dayName } from '../src/index.ts';
import { sampleWeekWithClearedNudge } from '../seed/sampleWeek.ts';

const plan = generatePlan(sampleWeekWithClearedNudge);

const line = (s = '') => process.stdout.write(s + '\n');

line('════════════════════════════════════════════════════════════');
line('  MARGIA ENGINE — reasoning over Louise\'s week');
line('════════════════════════════════════════════════════════════');
line();
line('PROTECTED (placed first, before any logistics):');
for (const s of plan.protected) {
  if (!s.placement) { line(`  · ${s.label} — could not fit her availability (surfaced, not crammed)`); continue; }
  const margin = s.hasMargin ? '   ✦ sits in manufactured margin' : '';
  line(`  · ${s.label.padEnd(14)} ${dayName(s.placement.day)} ${fmt(s.placement.start)}–${fmt(s.placement.end)}${margin}`);
}
line();
line('THE ONE SURFACED CHOREOGRAPHY MOVE (reasoning shown):');
if (plan.surfacedMove) {
  line(`  "${plan.surfacedMove.reason}"`);
} else {
  line('  (none this week)');
}
line();
line(`MARGIN MANUFACTURED: ${plan.marginMinutes} minutes reclaimed`);
line();
line('CO-RUNNING (choreography output — what runs under what):');
for (const e of plan.flexible) {
  if (e.co_running_with.length) {
    line(`  · ${e.label} ⇄ ${e.co_running_with.join(', ')}`);
  }
}
line();
line('HEALTH LAYER (cited, gated):');
for (const g of plan.screeningGaps) {
  line(`  · ${g.label.padEnd(30)} ${g.status.padEnd(14)} ${g.status === 'overdue' ? `(${g.months_overdue}mo over, ${g.guideline_source})` : ''}`);
}
line();
if (plan.healthNudge) {
  line('SURFACED HEALTH NUDGE (Sunday-Planning only):');
  line(`  "${plan.healthNudge.copy}"  — ${plan.healthNudge.guideline_source}`);
}
line();
if (plan.conflicts.length) {
  line('CONFLICTS (surfaced, never silently resolved):');
  for (const c of plan.conflicts) line(`  · ${c.message}`);
  line();
}
line('────────────────────────────────────────────────────────────');
line('FULL TRACE:');
for (const t of plan.trace) line(`  ${t}`);
line('════════════════════════════════════════════════════════════');
