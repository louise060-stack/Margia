import { createRequire } from 'module';
const require = createRequire('/home/claude/.npm-global/lib/node_modules/');
const { chromium } = require('playwright');

const base = 'http://localhost:3000';
const browser = await chromium.launch();

async function shot(name, { width, height, ds = 2, actions }) {
  const ctx = await browser.newContext({ viewport: { width, height }, deviceScaleFactor: ds });
  const page = await ctx.newPage();
  await page.goto(base, { waitUntil: 'networkidle' });
  // wait for the plan to render (choreography note or week grid present)
  await page.waitForSelector('.weekwrap', { timeout: 20000 });
  await page.waitForTimeout(1200); // let fonts + settle finish
  if (actions) await actions(page);
  await page.waitForTimeout(800);
  await page.screenshot({ path: `/home/claude/margia/${name}`, fullPage: true });
  await ctx.close();
  console.log('wrote', name);
}

// 1. Desktop — Sunday planning, light
await shot('shot-planning-light.png', { width: 1240, height: 1400 });

// 2. Desktop — 9pm depleted, dark (click the 9pm chip)
await shot('shot-depleted-dark.png', {
  width: 1240, height: 1200,
  actions: async (page) => { await page.getByRole('button', { name: '9pm' }).click(); await page.waitForTimeout(600); },
});

// 3. Mobile — Sunday planning
await shot('shot-mobile.png', { width: 402, height: 1500, ds: 2 });

await browser.close();
console.log('done');
