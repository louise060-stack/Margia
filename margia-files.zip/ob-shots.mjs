import { createRequire } from 'module';
const require = createRequire('/home/claude/.npm-global/lib/node_modules/');
const { chromium } = require('playwright');

const base = 'http://localhost:3000/onboarding';
const browser = await chromium.launch();

async function newPage(width, height) {
  const ctx = await browser.newContext({ viewport: { width, height }, deviceScaleFactor: 2 });
  const page = await ctx.newPage();
  return { ctx, page };
}
const snap = (page, name) => page.screenshot({ path: `/home/claude/margia/${name}` }).then(() => console.log('wrote', name));

// ---- desktop walkthrough ----
{
  const { ctx, page } = await newPage(1200, 900);
  await page.goto(base, { waitUntil: 'networkidle' });
  await page.waitForTimeout(900);
  await snap(page, 'ob-1-arrival.png');

  await page.getByRole('button', { name: 'Build my week' }).click();
  await page.waitForSelector('.ob-connect');
  await page.waitForTimeout(600);
  await snap(page, 'ob-2-connect.png');

  await page.getByRole('button', { name: 'Connect my calendar' }).click();
  await page.waitForSelector('.ob-reading');
  await page.waitForTimeout(1100); // let ~3 events stagger in
  await snap(page, 'ob-3-reading.png');

  // reading auto-advances to q1
  await page.waitForSelector('.ob-q', { timeout: 8000 });
  await page.fill('.ob-input', 'Any kind of exercise');
  await page.waitForTimeout(500);
  await snap(page, 'ob-4-q1.png');

  await page.getByRole('button', { name: 'Continue' }).click();
  await page.waitForSelector('.ob-options');
  await page.waitForTimeout(400);
  await snap(page, 'ob-5-q2.png');

  await page.getByRole('button', { name: 'Evening · after 7pm' }).click();
  await page.waitForTimeout(300);
  await page.getByRole('button', { name: 'Mostly me' }).click();
  await page.waitForSelector('.ob-chips');
  await page.getByRole('button', { name: '6–11' }).click();
  await page.fill('.ob-age', '38');
  await page.waitForTimeout(400);
  await snap(page, 'ob-6-q4.png');

  await page.getByRole('button', { name: 'Build my week' }).click();
  // assembling → reveal
  await page.waitForSelector('.ob-reveal .weekwrap', { timeout: 15000 });
  await page.waitForTimeout(1400);
  await snap(page, 'ob-7-reveal.png');
  await ctx.close();
}

// ---- mobile: arrival + a question ----
{
  const { ctx, page } = await newPage(402, 860);
  await page.goto(base, { waitUntil: 'networkidle' });
  await page.waitForTimeout(800);
  await snap(page, 'ob-m-arrival.png');
  await page.getByRole('button', { name: 'Build my week' }).click();
  await page.getByRole('button', { name: 'Connect my calendar' }).click();
  await page.waitForSelector('.ob-q', { timeout: 8000 });
  await page.fill('.ob-input', 'The dentist');
  await page.waitForTimeout(500);
  await snap(page, 'ob-m-q1.png');
  await ctx.close();
}

await browser.close();
console.log('done');
